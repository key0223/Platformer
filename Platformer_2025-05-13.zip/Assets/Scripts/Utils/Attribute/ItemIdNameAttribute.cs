using UnityEngine;

public class ItemIdNameAttribute : PropertyAttribute
{
    // �ܼ� ǥ�ÿ�
}

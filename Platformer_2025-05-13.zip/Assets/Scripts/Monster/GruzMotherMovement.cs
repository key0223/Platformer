using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Define;

public class GruzMotherMovement : MonsterMovement
{
    Rigidbody2D _rigid;
    PlayerMovement _target;

    [Header("Movement Settings")]
    [SerializeField] float _moveSpeed = 2f;
    [SerializeField] float _attackMoveSpeed = 4f;
    [SerializeField] float _distanceThreshold = 2f;
    [SerializeField] Vector2 _skillMoveDistance;


    Coroutine _coSkill;

    public override CreatureState State
    {
        get { return _state; }
        set
        {
            if (_state == value) return;
            _state = value;

            if(_coPatrol != null)
            {
                StopCoroutine(_coPatrol);
                _coPatrol = null;
            }
            if (_coMoving != null)
            {
                StopCoroutine(_coMoving);
                _coMoving = null;
            }
            if(_coSkill != null)
            {
                StopCoroutine(_coSkill);
                _coSkill = null;
            }

        }
    }
    protected override void Awake()
    {
        base.Awake();
        _rigid = GetComponent<Rigidbody2D>();
    }

    
    protected override void Update()
    {
        UpdateMovement();
    }

    protected override void UpdateMovement()
    {
        switch (State)
        {
            case CreatureState.Idle:
                UpdateIdle();
                break;
            case CreatureState.Moving:
                UpdateMoving();
                break;
            case CreatureState.Skill:
                UpdateSkill();
                break;
            case CreatureState.Dead:
                break;
        }
    }

    protected override void UpdateIdle()
    {
        if (_coPatrol == null)
            _coPatrol = StartCoroutine(CoPatrol());
       
    }

    protected override void UpdateMoving()
    {
        if (_coMoving == null)
            _coMoving = StartCoroutine(CoMoving());
    }

   

    void UpdateSkill()
    {
        if (_coSkill == null)
            _coSkill = StartCoroutine(CoSkill());
    }



    #region Coroutine

    protected override IEnumerator CoPatrol()
    {
        _target = GameObject.FindObjectOfType<PlayerMovement>();

        if (_target == null) yield break;

        Vector2 idlePos = (Vector2)transform.position + _skillMoveDistance;

        while (Vector2.Distance(idlePos, transform.position) > 0.1f)
        {
            Vector3 dir = idlePos - (Vector2)transform.position;
            _rigid.velocity = dir.normalized * _moveSpeed;
            yield return null;
        }
        yield return new WaitForSeconds(0.5f);
        State = CreatureState.Moving;
    }
    protected override IEnumerator CoMoving()
    {
        if (_target == null)
        {
            _target = null;

            yield return new WaitForSeconds(0.3f);
            State = CreatureState.Idle;

        }

        Vector3 dir = (_target.transform.position - transform.position);
        float distance = dir.magnitude;
        if (distance > _distanceThreshold)
            _rigid.velocity = dir.normalized * _moveSpeed;
        else
        {
            _rigid.velocity = Vector2.zero;
            State = CreatureState.Skill;

        }
    }

    // Before Attack 
    IEnumerator CoSkill()
    {
        Vector2 skillPos = (Vector2)transform.position + _skillMoveDistance;

        while (Vector2.Distance(skillPos, transform.position) > 0.1f)
        {
            Vector3 dir = skillPos - (Vector2)transform.position;
            _rigid.velocity = dir.normalized * _moveSpeed;
            yield return null;
        }

        _rigid.velocity = Vector2.zero;
        yield return StartCoroutine(CoAttack());
    }

    /* tlqka zhkd!@ */
    IEnumerator CoAttack()
    {
        Vector2 targetPos = _target.transform.position;

        while (Vector2.Distance(targetPos,transform.position)> _distanceThreshold)
        {
            Vector2 dir = targetPos - (Vector2)transform.position;
            _rigid.velocity = dir.normalized * _attackMoveSpeed;
            yield return null;
        }
       
            _rigid.velocity = Vector2.zero;
            yield return new WaitForSeconds(0.3f);
            State = CreatureState.Idle;
    }
    #endregion
}

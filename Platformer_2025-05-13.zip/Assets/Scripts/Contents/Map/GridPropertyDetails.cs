
public class GridPropertyDetails 
{
    public int gridX;
    public int gridY;
    public bool visited = false;
}
